import { b as createAstro, c as createComponent, m as maybeRenderHead, d as addAttribute, r as renderComponent, a as renderTemplate } from './astro/server_CAS8_Yex.mjs';
import { $ as $$Image } from './_astro_assets_C9PvZUsM.mjs';
import { f as formatDate } from './time_UFKwdKhw.mjs';

const $$Astro = createAstro("http://182.92.85.80:6000");
const $$BlogCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$BlogCard;
  const { blog } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<a class="group relative block rounded-xl outline-none ring-zinc-500 transition duration-500 focus-visible:ring dark:ring-zinc-200 dark:focus:outline-none"${addAttribute(`/posts/detail/${blog.id}/`, "href")} data-astro-prefetch> <div class="relative w-full flex-shrink-0 overflow-hidden rounded-xl before:absolute before:inset-x-0 before:z-[1] before:size-full before:bg-gradient-to-t before:from-neutral-900/[.7]"> ${renderComponent($$result, "Image", $$Image, { "class": "w-full h-full sm:h-[220px] md:h-[240px] start-0 top-0 size-full object-cover transition duration-500 group-hover:scale-110", "src": blog.cover, "alt": blog.title, "width": 1200, "height": 600, "draggable": "false", "loading": "eager", "format": "avif" })} </div> <div class="flex items-center"> <h3 class="mt-2 text-xl font-bold text-neutral-800 group-hover:text-orange-400 dark:text-neutral-200 dark:group-hover:text-orange-400"> ${blog.title} </h3> <div class="ms-auto"> ${blog.tags?.map((tag) => renderTemplate`<span class="bg-orange-300 group-hover:bg-orange-400 text-white text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-orange-500 dark:group-hover:bg-orange-700">${tag.name}</span>`)} </div> </div> <p class="mt-2 text-sm text-gray-600 dark:text-neutral-400 dark:group-hover:text-neutral-500"> ${formatDate(blog.createTime)} </p> </a>`;
}, "F:/VSCode/gblog-gblog-template/src/components/blog/BlogCard.astro", void 0);

export { $$BlogCard as $ };

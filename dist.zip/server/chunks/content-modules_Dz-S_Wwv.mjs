const contentModules = new Map();

export { contentModules as default };

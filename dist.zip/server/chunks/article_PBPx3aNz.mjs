import axios from 'axios';

const service = axios.create({
  baseURL: "http://127.0.0.1:8800",
  timeout: 1e4
});
service.interceptors.request.use(
  (config) => {
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);
service.interceptors.response.use(
  (response) => {
    const res = response.data;
    if (res.code === 200 || response.status === 200) {
      return res;
    } else if (res.code === 404) {
      return Promise.reject(new Error("请求路径不存在"));
    } else if (res.code === 401) {
      return Promise.reject(new Error("当前登录已过期，请重新登录"));
    } else {
      return Promise.reject(new Error(res.message || "请求失败"));
    }
  },
  (error) => {
    return Promise.reject(error);
  }
);

/**
 * 获取文章详情
 */
function getArticleDetailApi(id) {
  return service({
    url: `/api/article/detail/${id}`,
    method: 'get'
  })
} 

/**
 * 获取文章列表
 */
function getArticlesApi(params) {
  return service({
      url: '/api/article/list',
      method: 'get',
      params: params
  })
}

/**
 * 获取推荐文章
 */
function getRecommendArticlesApi() {
  return service({
    url: '/api/article/getRecommends',
    method: 'get',
  })
}

/**
 * 获取分类
 */
function getCategoriesApi() {
  return service({
    url: '/api/article/categories',
    method: 'get'
  })
}

/**
 * 获取所有分类
 */
function getAllCategoriesApi() {
  return service({
    url: '/api/article/categorie-all',
    method: 'get'
  })
}


/**
 * 获取时间线
 * @returns 
 */
function getTimelineApi() {
  return service({
    url: `/api/getTimeline`,
    method: 'get'
  })
}

/**
 * 查询时间线文章
 * @param {*} date 时间线日期
 * @returns 
 */
function queryTimelineArticlesApi(date) {
  return service({
    url: `/api/queryTimelineArticles`,
    method: 'get',
    params: {
      date
    }
  })
}

export { getCategoriesApi as a, getArticleDetailApi as b, getRecommendArticlesApi as c, getAllCategoriesApi as d, getTimelineApi as e, getArticlesApi as g, queryTimelineArticlesApi as q };

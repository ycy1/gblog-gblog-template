import path from 'node:path';
import sharp from 'sharp';
import ico from 'sharp-ico';
export { renderers } from '../renderers.mjs';

const faviconSrc = path.resolve("src/images/avataaars.jpg");
const GET = async () => {
  const sizes = [16, 32];
  const buffers = await Promise.all(
    sizes.map(async (size) => {
      return await sharp(faviconSrc).resize(size).toFormat("png").toBuffer();
    })
  );
  const icoBuffer = ico.encode(buffers);
  return new Response(icoBuffer, {
    headers: { "Content-Type": "image/x-icon" }
  });
};

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    GET
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

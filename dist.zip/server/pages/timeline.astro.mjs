/* empty css                                */
import { b as createAstro, c as createComponent, m as maybeRenderHead, d as addAttribute, a as renderTemplate, r as renderComponent } from '../chunks/astro/server_CAS8_Yex.mjs';
import { $ as $$BaseLayout } from '../chunks/BaseLayout_CEGNqrUJ.mjs';
import { q as queryTimelineArticlesApi, e as getTimelineApi } from '../chunks/article_BYY0RCVB.mjs';
import { S as SITE } from '../chunks/config_pfltf_po.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro$1 = createAstro("http://182.92.85.80:6000");
const $$BlogTimeline = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$BlogTimeline;
  const { blog } = Astro2.props;
  const timeline = await queryTimelineArticlesApi(blog.date);
  return renderTemplate`${maybeRenderHead()}<div class="max-w-3xl mx-auto"> <div class="p-5 mb-4 border border-gray-100 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"> <time class="text-lg font-semibold text-gray-900 dark:text-white">${blog.date}</time> <ol class="mt-3 divide-y divide-gray-200 dark:divide-gray-700"> ${timeline.data.map((p) => renderTemplate`<li class="rounded-xl hover:bg-gray-100 hover:text-orange-500 dark:text-white dark:hover:bg-gray-700 dark:hover:text-orange-500"> <a${addAttribute(`/posts/detail/${p.id}`, "href")} class="p-2 group"> <div>${p.title}</div> <div class="items-center block sm:flex m-6"> <img class="w-12 h-12 mb-3 me-3 rounded-full sm:mb-0 group-hover:scale-110 transition duration-550"${addAttribute(p.cover, "src")} alt="Jese Leos image"> <div class="text-gray-600 dark:text-gray-400"> <div class="text-base font-normal line-clamp-2"> ${p.summary} </div> </div> </div> </a> </li>`)} </ol> </div> </div>`;
}, "F:/shiyi-blog-master/gblog-gblog-template/src/components/blog/BlogTimeline.astro", void 0);

const $$Astro = createAstro("http://182.92.85.80:6000");
const $$Timeline = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Timeline;
  const description = `Godruoyi All Posts, Currently written articles. Let's keep up the good work!`;
  const URL = Astro2.url.href;
  const timeline = await getTimelineApi();
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "\u65F6\u95F4\u7EBF", "description": description, "structuredData": {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "inLanguage": "en-US",
    "@id": URL,
    "url": URL,
    "name": `Timeline - ${SITE.title}`,
    "description": description,
    "isPartOf": {
      "@type": "WebSite",
      "url": SITE.url,
      "name": SITE.title,
      "description": SITE.description
    }
  } }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="mx-auto max-w-[85rem] mt-10 lg:mt-10 px-4 py-10 sm:px-6 lg:px-8 lg:py-14"> <div class="max-w-3xl mx-auto mb-10 lg:mb-14"> <h2 class="text-3xl font-bold text-neutral-800 dark:text-neutral-200 md:text-4xl md:leading-tight">时间线</h2> <!-- <p class="mt-4 text-lg group text-pretty text-neutral-600 dark:text-neutral-400">
                目前一共写了 <span class="group-hover:text-yellow-500 group-hover:dark:text-yellow-400">{posts.length}</span> 篇文章，再接再厉吧 💪
            </p> --> </div> ${timeline.data.map((p) => renderTemplate`${renderComponent($$result2, "BlogTimeline", $$BlogTimeline, { "blog": p })}`)} </section> ` })}`;
}, "F:/shiyi-blog-master/gblog-gblog-template/src/pages/timeline.astro", void 0);

const $$file = "F:/shiyi-blog-master/gblog-gblog-template/src/pages/timeline.astro";
const $$url = "/timeline";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Timeline,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

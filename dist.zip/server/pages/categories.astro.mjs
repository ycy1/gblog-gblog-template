/* empty css                                */
import { b as createAstro, c as createComponent, m as maybeRenderHead, d as addAttribute, a as renderTemplate, r as renderComponent } from '../chunks/astro/server_CAS8_Yex.mjs';
import { g as getCollection } from '../chunks/_astro_content_1Y5Q0bgb.mjs';
import { $ as $$BaseLayout } from '../chunks/BaseLayout_CEGNqrUJ.mjs';
import { $ as $$MainSection } from '../chunks/MainSection_Cmg3MsKP.mjs';
import { t as timeago } from '../chunks/time_UFKwdKhw.mjs';
import { S as SITE } from '../chunks/config_pfltf_po.mjs';
import { a as getCategoriesApi } from '../chunks/article_BYY0RCVB.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro$1 = createAstro("http://182.92.85.80:6000");
const $$BlogCategory = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$BlogCategory;
  const { id, title, description, count, publishDate, isHot } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<a${addAttribute(`/categories/detail/${id}?title=${title}&description=${description}`, "href")} class="flex flex-col justify-between size-full bg-neutral-100 shadow-lg rounded-lg p-5 dark:bg-neutral-900/30 group"> <!-- 是否热门 --> ${isHot && renderTemplate`<span style="position: relative; bottom: 25px;right: 25px; margin-bottom: -45px;" class="inline-flex items-center justify-center w-6 h-6 me-2 text-sm font-semibold text-blue-800 bg-blue-100 rounded-full dark:bg-gray-700 dark:text-blue-400"> <svg class="w-8 h-8" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20"> <path fill="currentColor" d="m18.774 8.245-.892-.893a1.5 1.5 0 0 1-.437-1.052V5.036a2.484 2.484 0 0 0-2.48-2.48H13.7a1.5 1.5 0 0 1-1.052-.438l-.893-.892a2.484 2.484 0 0 0-3.51 0l-.893.892a1.5 1.5 0 0 1-1.052.437H5.036a2.484 2.484 0 0 0-2.48 2.481V6.3a1.5 1.5 0 0 1-.438 1.052l-.892.893a2.484 2.484 0 0 0 0 3.51l.892.893a1.5 1.5 0 0 1 .437 1.052v1.264a2.484 2.484 0 0 0 2.481 2.481H6.3a1.5 1.5 0 0 1 1.052.437l.893.892a2.484 2.484 0 0 0 3.51 0l.893-.892a1.5 1.5 0 0 1 1.052-.437h1.264a2.484 2.484 0 0 0 2.481-2.48V13.7a1.5 1.5 0 0 1 .437-1.052l.892-.893a2.484 2.484 0 0 0 0-3.51Z"></path> <path fill="#fff" d="M8 13a1 1 0 0 1-.707-.293l-2-2a1 1 0 1 1 1.414-1.414l1.42 1.42 5.318-3.545a1 1 0 0 1 1.11 1.664l-6 4A1 1 0 0 1 8 13Z"></path> </svg> <span class="sr-only">Icon description</span> </span>

        <div style="top: -5%;
        left: 100%;" class="relative inline-flex items-center justify-center w-6 h-6 text-xs font-bold text-white bg-red-500 border-2 border-white rounded-full dark:border-gray-900">${count}</div>`} <div class="flex justify-between items-center mb-3"> <div class="flex justify-center gap-x-4 items-center"> <div class="flex-shrink-0"> <h3 class="text-lg font-semibold tracking-tight text-neutral-600 group-hover:text-orange-400 dark:text-neutral-300 dark:group-hover:text-orange-300"> ${title} </h3> </div> </div> </div> <p${addAttribute(description, "title")} class="line-clamp-2 text-neutral-500 min-h-[50px] group-hover:text-neutral-600 dark:text-neutral-500 dark:group-hover:text-neutral-400"> ${description} </p> <div class="flex mt-2 mb-0 gap-x-5"> <span class="text-xs inline-flex items-center rounded me-2 text-neutral-500 group-hover:text-neutral-600 dark:text-neutral-500 dark:group-hover:text-neutral-400"> <svg class="w-3 h-3 me-1.5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"> <rect width="8" height="4" x="8" y="2" rx="1"></rect> <path d="M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-.5"></path> <path d="M16 4h2a2 2 0 0 1 1.73 1"></path> <path d="M8 18h1"></path> <path d="M18.4 9.6a2 2 0 0 1 3 3L17 17l-4 1 1-4Z"></path> </svg> ${count} posts
</span> <span class="text-xs inline-flex items-center rounded me-2 text-neutral-500 group-hover:text-neutral-600 dark:text-neutral-500 dark:group-hover:text-neutral-400"> <svg class="w-3 h-3 me-1.5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"> <circle cx="12" cy="12" r="10"></circle> <polyline points="12 6 12 12 16 14"></polyline> </svg>
update ${publishDate} </span> </div> </a>`;
}, "F:/shiyi-blog-master/gblog-gblog-template/src/components/blog/BlogCategory.astro", void 0);

const $$Astro = createAstro("http://182.92.85.80:6000");
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  (await getCollection("posts")).sort(
    (a, b) => b.data.pubDate.valueOf() - a.data.pubDate.valueOf()
  ).reduce((acc, obj) => {
    let posts = acc.get(obj.data.category);
    if (!posts) {
      posts = [];
    }
    posts.push(obj);
    acc.set(obj.data.category, posts);
    return acc;
  }, /* @__PURE__ */ new Map());
  const categoriesApi = await getCategoriesApi();
  const categories = categoriesApi.data;
  const description = "\u4EE5\u4E0B\u662F\u6211\u611F\u5174\u8DA3\u7684\u4E00\u4E9B\u7C7B\u522B\uFF0C\u5305\u62ECSQL\u3001AI\u548C\u5979\u7684\u751F\u6D3B\u3002";
  const URL = Astro2.url.href;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "\u5206\u7C7B", "description": description, "structuredData": {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "inLanguage": "en-US",
    "@id": URL,
    "url": URL,
    "name": `All Categories - ${SITE.title}`,
    "description": description,
    "isPartOf": {
      "@type": "WebSite",
      "url": SITE.url,
      "name": SITE.title,
      "description": SITE.description
    }
  } }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "MainSection", $$MainSection, { "title": "\u7C7B\u522B", "subTitle": description })} ${maybeRenderHead()}<section class="mx-auto px-4 py-10 sm:px-6 lg:px-8 lg:pt-10 lg:py-14 2xl:max-w-full"> <div class="grid sm:grid-cols-2 lg:grid-cols-3 items-center gap-6 md:gap-10"> ${categories.map((c) => renderTemplate`${renderComponent($$result2, "BlogCategory", $$BlogCategory, { "id": c.id, "title": c.name, "description": c.remark, "count": c.posts?.length ?? 0, "isHot": c.isHot ? true : false, "publishDate": timeago(c.posts?.[0]?.data?.pubDate) })}`)} </div> </section> ` })}`;
}, "F:/shiyi-blog-master/gblog-gblog-template/src/pages/categories/index.astro", void 0);

const $$file = "F:/shiyi-blog-master/gblog-gblog-template/src/pages/categories/index.astro";
const $$url = "/categories";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

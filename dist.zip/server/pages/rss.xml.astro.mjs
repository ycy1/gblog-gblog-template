import rss from '@astrojs/rss';
import { g as getCollection } from '../chunks/_astro_content_1Y5Q0bgb.mjs';
import { S as SITE } from '../chunks/config_pfltf_po.mjs';
export { renderers } from '../renderers.mjs';

async function GET() {
  const posts = (await getCollection("posts")).sort(
    (a, b) => b.data.pubDate.valueOf() - a.data.pubDate.valueOf()
  );
  return rss({
    title: SITE.title,
    description: SITE.description,
    site: SITE.url,
    items: posts.map((post) => ({
      ...post.data,
      link: `/posts/${post.slug}/`
    }))
  });
}

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    GET
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

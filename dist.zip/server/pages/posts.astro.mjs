/* empty css                                */
import { b as createAstro, c as createComponent, m as maybeRenderHead, r as renderComponent, a as renderTemplate } from '../chunks/astro/server_CAS8_Yex.mjs';
import { g as getCollection } from '../chunks/_astro_content_yTRgPH__.mjs';
import { $ as $$BaseLayout } from '../chunks/BaseLayout_BrqnI_2k.mjs';
import { $ as $$MainSection } from '../chunks/MainSection_C7kD5uwa.mjs';
import { $ as $$PrimaryCTA } from '../chunks/PrimaryCTA_BAIXBEzD.mjs';
import { $ as $$Image } from '../chunks/_astro_assets_C9PvZUsM.mjs';
import { $ as $$Icon } from '../chunks/icon_C0nAlCbs.mjs';
import { $ as $$BlogCard } from '../chunks/BlogCard_B0HFkVLx.mjs';
import { S as SITE } from '../chunks/config_pfltf_po.mjs';
import { g as getArticlesApi, c as getRecommendArticlesApi } from '../chunks/article_PBPx3aNz.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro$4 = createAstro("http://182.92.85.80:6000");
const $$LeftSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$LeftSection;
  const { title, subTitle, btnExists, btnTitle, btnURL, img, imgAlt } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section class="mx-auto max-w-[85rem] items-center gap-8 px-4 py-10 sm:px-6 sm:py-16 md:grid md:grid-cols-2 lg:grid lg:grid-cols-2 lg:px-8 lg:py-14 xl:gap-16 2xl:max-w-full"> ${renderComponent($$result, "Image", $$Image, { "class": "w-full object-cover aspect-[10/5] rounded-lg", "src": img, "alt": imgAlt, "draggable": "false", "loading": "lazy", "width": 500, "height": 300 })} <div class="mt-4 md:mt-0"> <h2 class="mb-4 text-balance text-4xl font-extrabold tracking-tight text-neutral-800 dark:text-neutral-200"> ${title} </h2> <p class="mb-4 line-clamp-2 max-w-prose text-pretty font-light text-neutral-600 dark:text-neutral-400 sm:text-lg"> ${subTitle} </p> ${btnExists ? renderTemplate`${renderComponent($$result, "PrimaryCTA", $$PrimaryCTA, { "title": btnTitle, "url": btnURL })}` : null} </div> </section>`;
}, "F:/VSCode/gblog-gblog-template/src/components/blog/blocks/LeftSection.astro", void 0);

const $$Astro$3 = createAstro("http://182.92.85.80:6000");
const $$RightSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$RightSection;
  const {
    title,
    subTitle,
    btnExists,
    btnTitle,
    btnURL,
    single,
    imgOne,
    imgOneAlt,
    imgTwo,
    imgTwoAlt
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section class="mx-auto max-w-[85rem] items-center gap-16 px-4 py-10 sm:px-6 lg:grid lg:grid-cols-2 lg:px-8 lg:py-14 2xl:max-w-full"> <div> <h2 class="mb-4 text-balance text-4xl font-extrabold tracking-tight text-neutral-800 dark:text-neutral-200"> ${title} </h2> <p class="mb-4 line-clamp-2 max-w-prose text-pretty font-light text-neutral-600 dark:text-neutral-400 sm:text-lg"> ${subTitle} </p> ${btnExists ? renderTemplate`${renderComponent($$result, "PrimaryCTA", $$PrimaryCTA, { "title": btnTitle, "url": btnURL })}` : null} </div> ${single ? renderTemplate`<div class="mt-8"> ${renderComponent($$result, "Image", $$Image, { "class": "w-full object-cover aspect-[10/5] rounded-lg", "src": imgOne, "alt": imgOneAlt, "format": "avif", "loading": "lazy", "width": 500, "height": 300 })} </div>` : renderTemplate`<div class="mt-8 grid grid-cols-2 gap-4"> ${renderComponent($$result, "Image", $$Image, { "class": "w-full rounded-xl", "src": imgOne, "alt": imgOneAlt, "draggable": "false", "format": "avif", "loading": "lazy" })} ${renderComponent($$result, "Image", $$Image, { "class": "mt-4 w-full rounded-xl lg:mt-10", "src": imgTwo, "alt": imgTwoAlt, "draggable": "false", "format": "avif", "loading": "lazy" })} </div>`} </section>`;
}, "F:/VSCode/gblog-gblog-template/src/components/blog/blocks/RightSection.astro", void 0);

const $$Astro$2 = createAstro("http://182.92.85.80:6000");
const $$BlogRecentCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$BlogRecentCard;
  const { blogs } = Astro2.props;
  return renderTemplate`${// @ts-ignore
  blogs.map((b, index) => index % 2 === 0 ? renderTemplate`${renderComponent($$result, "LeftSection", $$LeftSection, { "title": b.title, "subTitle": b.summary, "btnExists": true, "btnTitle": "\u9605\u8BFB\u66F4\u591A", "btnURL": `/posts/detail/${b.id}`, "img": b.cover, "imgAlt": b.title })}` : renderTemplate`${renderComponent($$result, "RightSection", $$RightSection, { "title": b.title, "subTitle": b.summary, "btnExists": true, "btnTitle": "\u9605\u8BFB\u66F4\u591A", "btnURL": `/posts/detail/${b.id}`, "img": b.cover, "imgAlt": b.title, "single": !b.cardImage2, "imgOne": b.cover, "imgOneAlt": b.title, "imgTwo": b.cardImage2, "imgTwoAlt": b.title })}`)}`;
}, "F:/VSCode/gblog-gblog-template/src/components/blog/BlogRecentCard.astro", void 0);

const $$Astro$1 = createAstro("http://182.92.85.80:6000");
const $$BlogSelectedArticle = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$BlogSelectedArticle;
  const { posts } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section class="mx-auto max-w-[85rem] px-4 py-8 sm:px-6 lg:px-8 mb-10 2xl:max-w-full"> <div class="text-left"> <h2 class="mb-4 text-balance text-5xl font-extrabold tracking-tight text-neutral-800 dark:text-neutral-200">
精选文章
</h2> <p class="mb-8 max-w-prose text-pretty font-light text-neutral-600 dark:text-neutral-400 sm:text-xl">
这里有几篇我认为还不错的文章，希望你也喜欢。
</p> </div> <div class="grid gap-6 grid-cols-1 lg:grid-cols-3 sm:grid-cols-2"> ${posts.map((b) => renderTemplate`${renderComponent($$result, "BlogCard", $$BlogCard, { "blog": b })}`)} </div> <div class="text-center mt-6"> <a href="/timeline" class="group inline-flex items-center justify-center gap-x-2 rounded-full px-4 py-3 text-sm font-bold text-neutral-50 ring-zinc-500 transition duration-300 focus-visible:ring outline-none border border-transparent bg-orange-400 hover:bg-orange-500 active:bg-orange-500 dark:focus:outline-none disabled:pointer-events-none disabled:opacity-50 2xl:text-base dark:ring-zinc-200"> <div class="flex items-center gap-x-2"> <p>想了解更多 ?</p>Go
${renderComponent($$result, "Icon", $$Icon, { "name": "arrowRight", "class": "h-4 w-4 flex-shrink-0 transition duration-300 group-hover:translate-x-1" })} </div> </a> </div> </section>`;
}, "F:/VSCode/gblog-gblog-template/src/components/blog/BlogSelectedArticle.astro", void 0);

const $$Astro = createAstro("http://182.92.85.80:6000");
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  const posts = (await getCollection("posts")).sort(
    (a, b) => b.data.pubDate.valueOf() - a.data.pubDate.valueOf()
  );
  const articles = await getArticlesApi();
  const recentPosts = articles.data.records.slice(0, 3);
  posts.filter((p) => p.data.selected);
  const recommendPosts = await getRecommendArticlesApi();
  const description = "Here are some articles that Godruoyi believes are not bad, hope you enjoy them.";
  const URL = Astro2.url.href;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "\u6587\u7AE0", "description": description, "structuredData": {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "inLanguage": "en-US",
    "@id": URL,
    "url": URL,
    "name": `All Blogs - ${SITE.title}`,
    "description": description,
    "isPartOf": {
      "@type": "WebSite",
      "url": SITE.url,
      "name": SITE.title,
      "description": SITE.description
    }
  } }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "MainSection", $$MainSection, { "title": "\u5199\u4F60\u6240\u60F3", "subTitle": "\u751F\u6D3B\u4E0D\u80FD\u8BA9\u4EBA\u5904\u5904\u6EE1\u610F\uFF0C\u4F46\u6211\u4EEC\u8FD8\u8981\u70ED\u60C5\u7684\u751F\u6D3B\u4E0B\u53BB", "btnExists": true, "btnTitle": "\u6240\u6709\u6587\u7AE0", "btnURL": "/timeline" })} ${renderComponent($$result2, "BlogRecentCard", $$BlogRecentCard, { "blogs": recentPosts })} ${renderComponent($$result2, "BlogSelectedArticle", $$BlogSelectedArticle, { "posts": recommendPosts.data })} ` })}`;
}, "F:/VSCode/gblog-gblog-template/src/pages/posts/index.astro", void 0);

const $$file = "F:/VSCode/gblog-gblog-template/src/pages/posts/index.astro";
const $$url = "/posts";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

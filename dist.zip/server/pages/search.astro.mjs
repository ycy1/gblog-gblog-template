/* empty css                                */
import { c as createComponent, r as renderComponent, e as renderScript, a as renderTemplate, m as maybeRenderHead, d as addAttribute } from '../chunks/astro/server_CAS8_Yex.mjs';
import { $ as $$BaseLayout } from '../chunks/BaseLayout_BrqnI_2k.mjs';
import { d as getAllCategoriesApi } from '../chunks/article_PBPx3aNz.mjs';
export { renderers } from '../renderers.mjs';

const $$Search = createComponent(async ($$result, $$props, $$slots) => {
  const categoriesRes = await getAllCategoriesApi();
  const categories = categoriesRes.data;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "\u641C\u7D22", "description": "\u641C\u7D22\u672C\u7AD9\u6587\u7AE0" }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="mx-auto max-w-[85rem] px-4 py-8 sm:px-6 lg:px-8 mb-10 2xl:max-w-full"> <!-- 搜索框 --> <div class="flex"> <button id="dropdown-button" data-dropdown-toggle="dropdown" class="flex-shrink-0 z-10 inline-flex items-center py-2.5 px-4 text-sm font-medium text-center text-gray-900 bg-gray-100 border-e-0 border-gray-300 dark:border-gray-700 dark:text-white rounded-s-lg hover:bg-gray-200 focus:ring-4 focus:outline-none focus:ring-gray-300 dark:bg-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-800" type="button"> <span id="allCategory" class="w-16 truncate">所有分类</span> <svg class="w-2.5 h-2.5 ms-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6"> <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4"></path> </svg> </button> <div id="dropdown" style="position: absolute;
          inset: 0px auto auto -20px;
          margin: 0px;
          transform: translate3d(106.4px, 183.2px, 0px);" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-52 dark:bg-gray-700"> <ul class="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="dropdown-button"> <a title="clear" data-category="clear" class="categoryLi"> <li class="truncate border-b mx-1 rounded-sm border-gray-300 dark:border-gray-600 py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white"> <button type="button" class="w-4/5 focus:outline-none text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900">Clear</button> </li> </a> ${categories.map((category) => {
    return renderTemplate`<a${addAttribute(category.name, "title")}${addAttribute(category.id, "data-category")} class="categoryLi" style="cursor: pointer;"> <li class="truncate border-b mx-1 rounded-sm border-gray-300 dark:border-gray-600 py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white"> ${category.name} </li> </a>`;
  })} </ul> </div> <div class="relative w-full"> <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none"> <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20"> <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"></path> </svg> </div> <input type="search" id="searchBox" class="rounded-r-lg ps-10 block px-2.5 pb-2.5 pt-5 w-full text-sm text-gray-900 bg-gray-50 dark:bg-gray-700 border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder="" required> <label for="searchBox" class="ps-10 absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-4 scale-75 top-4 z-10 origin-[0] start-2.5 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-4 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto">
Search what you think
</label> <button type="button" class="absolute top-0 end-0 p-2.5 h-full text-sm font-medium text-white bg-blue-700 rounded-e-lg border border-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"> <svg class="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20"> <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"></path> </svg> </button> </div> </div> <p id="floating_helper_text" class="mt-2 text-xs text-gray-500 dark:text-gray-400">
按文章标题模糊查询
<a href="#" class="text-blue-600 dark:text-blue-500">
搜你所想
</a>
😍
</p> <!-- 结果集 --> <div id="results" class="mt-12 grid grid-cols-[repeat(auto-fit,minmax(375px,1fr))] gap-8 justify-items-center"></div> </section> ` })} ${renderScript($$result, "F:/VSCode/gblog-gblog-template/src/pages/search.astro?astro&type=script&index=0&lang.ts")}`;
}, "F:/VSCode/gblog-gblog-template/src/pages/search.astro", void 0);

const $$file = "F:/VSCode/gblog-gblog-template/src/pages/search.astro";
const $$url = "/search";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Search,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

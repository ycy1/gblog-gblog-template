/* empty css                                      */
import { b as createAstro, c as createComponent, m as maybeRenderHead, d as addAttribute, r as renderComponent, a as renderTemplate, e as renderScript } from '../../../chunks/astro/server_CAS8_Yex.mjs';
import { $ as $$BaseLayout } from '../../../chunks/BaseLayout_BrqnI_2k.mjs';
import { $ as $$MainSection } from '../../../chunks/MainSection_C7kD5uwa.mjs';
import { $ as $$BlogCard } from '../../../chunks/BlogCard_B0HFkVLx.mjs';
import { $ as $$Image } from '../../../chunks/_astro_assets_C9PvZUsM.mjs';
import { f as formatDate } from '../../../chunks/time_UFKwdKhw.mjs';
import { S as SITE } from '../../../chunks/config_pfltf_po.mjs';
import { g as getArticlesApi } from '../../../chunks/article_PBPx3aNz.mjs';
export { renderers } from '../../../renderers.mjs';

const $$Astro$1 = createAstro("http://182.92.85.80:6000");
const $$BlogList = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$BlogList;
  const { blog } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<a class="group"${addAttribute(`/posts/detail/${blog.id}/`, "href")} data-astro-prefetch> <div class="border-b border-gray-300 dark:border-gray-600 pt-10 pb-5"> <div> <div class="flex items-center space-x-4 rtl:space-x-reverse"> <div class="flex-shrink-0"> ${renderComponent($$result, "Image", $$Image, { "class": "w-8 h-8 rounded-full  start-0 top-0 size-full object-cover transition duration-550 group-hover:scale-150", "src": blog.cover, "alt": blog.title, "draggable": "false", "loading": "eager", "width": 100, "height": 100 })} </div> <div class="flex-1 min-w-0"> <div class="flex items-center"> <p class="text-lg font-semibold text-gray-900 truncate group-hover:text-orange-500 dark:text-white dark:group-hover:text-orange-500"> ${blog.title} </p> </div> <p${addAttribute(blog.summary, "title")} class="text-sm text-gray-500 truncate dark:text-gray-400"> ${blog.summary} </p> </div> <div class="text-right text-sm pt-5 text-gray-500 dark:text-gray-400"> <p>${formatDate(blog.createTime)}</p> <div class="mt-2"> ${blog.tags?.map((tag) => renderTemplate`<span class="bg-orange-300 group-hover:bg-orange-400 text-white text-xs font-medium ms-2 px-2.5 py-0.5 rounded dark:bg-orange-500 dark:group-hover:bg-orange-700">${tag.name}</span>`)} </div> </div> </div> </div> </div> </a>`;
}, "F:/VSCode/gblog-gblog-template/src/components/blog/BlogList.astro", void 0);

const $$Astro = createAstro("http://182.92.85.80:6000");
const $$id = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$id;
  const URL = Astro2.url.href;
  const categoriesURL = `${Astro2.url.origin}/categories`;
  const { id } = Astro2.params;
  const title = Astro2.url.searchParams.get("title") === "null" ? "" : Astro2.url.searchParams.get("title") || "";
  const description = Astro2.url.searchParams.get("description") === "null" ? "" : Astro2.url.searchParams.get("description") || "";
  const articles = await getArticlesApi({
    categoryId: id
  });
  const posts = articles.data.records || [];
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": title, "description": description, "structuredData": {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "inLanguage": "en-US",
    "@id": URL,
    "url": URL,
    "name": `${title} - ${SITE.title}`,
    "description": description,
    "isPartOf": {
      "@type": "WebSite",
      "url": categoriesURL,
      "name": `All Categories - ${SITE.title}`
    }
  } }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "MainSection", $$MainSection, { "title": title, "subTitle": description, "btnExists": true, "isCategory": true, "btnTitle": "\u5206\u7C7B\u5217\u8868", "btnURL": "/categories" })} ${maybeRenderHead()}<section class="mx-auto max-w-[85rem] px-4 py-8 sm:px-6 lg:px-8 mb-10 2xl:max-w-full"> <!-- 卡片 --> <div id="cardBlog" class="grid gap-6 grid-cols-1 lg:grid-cols-3 sm:grid-cols-2"> ${posts.map((b) => renderTemplate`${renderComponent($$result2, "BlogCard", $$BlogCard, { "blog": b })}`)} </div> <!-- 列表 --> <div id="listBlog" class="block gap-6 grid-cols-1 lg:grid-cols-3 sm:grid-cols-2"> ${posts.map((b) => renderTemplate`${renderComponent($$result2, "BlogList", $$BlogList, { "blog": b })}`)} </div> </section> ` })} ${renderScript($$result, "F:/VSCode/gblog-gblog-template/src/pages/categories/detail/[id].astro?astro&type=script&index=0&lang.ts")}`;
}, "F:/VSCode/gblog-gblog-template/src/pages/categories/detail/[id].astro", void 0);

const $$file = "F:/VSCode/gblog-gblog-template/src/pages/categories/detail/[id].astro";
const $$url = "/categories/detail/[id]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$id,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

/* empty css                                */
import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_CAS8_Yex.mjs';
import { $ as $$BaseLayout } from '../chunks/BaseLayout_CEGNqrUJ.mjs';
import { $ as $$PrimaryCTA } from '../chunks/PrimaryCTA_CtCzlMqq.mjs';
import { S as SITE } from '../chunks/config_pfltf_po.mjs';
export { renderers } from '../renderers.mjs';

const $$404 = createComponent(($$result, $$props, $$slots) => {
  const pageTitle = `Page Not Found | ${SITE.title}`;
  const title = "Not Found";
  const subTitle = "\u6211\u4EEC\u771F\u7684\u5C3D\u529B\u4E86\uFF0C\u4F46\u8FD8\u662F\u6CA1\u627E\u5230\u60A8\u8981\u7684\u5185\u5BB9";
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": pageTitle }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="grid h-svh place-content-center"> <div class="mx-auto max-w-screen-xl px-4 py-8 lg:px-6 lg:py-16"> <div class="mx-auto max-w-screen-sm text-center"> <h1 class="text-dark mb-4 text-7xl font-extrabold text-yellow-500 dark:text-yellow-400 lg:text-9xl"> ${title} </h1> <p class="mb-4 text-balance text-3xl font-bold tracking-tight text-neutral-700 dark:text-neutral-300 md:text-4xl"> ${subTitle} </p> ${renderComponent($$result2, "PrimaryCTA", $$PrimaryCTA, { "title": "Home", "url": "/" })} </div> </div> </section> ` })}`;
}, "F:/shiyi-blog-master/gblog-gblog-template/src/pages/404.astro", void 0);

const $$file = "F:/shiyi-blog-master/gblog-gblog-template/src/pages/404.astro";
const $$url = "/404";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$404,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };

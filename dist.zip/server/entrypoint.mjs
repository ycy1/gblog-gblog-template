import './chunks/virtual_CBCFsnSf.mjs';
import { g as getArticlesApi } from './chunks/article_BYY0RCVB.mjs';
import { d as defineAction } from './chunks/server_4MfBX7KP.mjs';
import { o as objectType, n as numberType, s as stringType } from './chunks/astro/server_CAS8_Yex.mjs';

const server = {
  searchArticles: defineAction({
    input: objectType({
      keyword: stringType(),
      categoryId: stringType().optional(),
      pageNum: numberType().optional(),
      pageSize: numberType().optional()
    }),
    handler: async (params) => {
      console.log(params);
      const resultsContainer = await getArticlesApi(params);
      return resultsContainer.data.records;
    }
  })
};

export { server };

import { renderers } from './renderers.mjs';
import { c as createExports, s as serverEntrypointModule } from './chunks/_@astrojs-ssr-adapter_o8nLWo1L.mjs';
import { manifest } from './manifest_B6BVxQzj.mjs';

const serverIslandMap = new Map();;

const _page0 = () => import('./pages/_image.astro.mjs');
const _page1 = () => import('./pages/_actions/_---path_.astro.mjs');
const _page2 = () => import('./pages/404.astro.mjs');
const _page3 = () => import('./pages/categories/detail/_id_.astro.mjs');
const _page4 = () => import('./pages/categories.astro.mjs');
const _page5 = () => import('./pages/contact.astro.mjs');
const _page6 = () => import('./pages/favicon.ico.astro.mjs');
const _page7 = () => import('./pages/friends.astro.mjs');
const _page8 = () => import('./pages/posts/detail/_id_.astro.mjs');
const _page9 = () => import('./pages/posts.astro.mjs');
const _page10 = () => import('./pages/robots.txt.astro.mjs');
const _page11 = () => import('./pages/rss.xml.astro.mjs');
const _page12 = () => import('./pages/search.astro.mjs');
const _page13 = () => import('./pages/timeline.astro.mjs');
const _page14 = () => import('./pages/index.astro.mjs');
const pageMap = new Map([
    ["node_modules/.pnpm/astro@5.15.1_@types+node@24_82b027862b686fce6545b2db4cf1bae3/node_modules/astro/dist/assets/endpoint/node.js", _page0],
    ["node_modules/.pnpm/astro@5.15.1_@types+node@24_82b027862b686fce6545b2db4cf1bae3/node_modules/astro/dist/actions/runtime/route.js", _page1],
    ["src/pages/404.astro", _page2],
    ["src/pages/categories/detail/[id].astro", _page3],
    ["src/pages/categories/index.astro", _page4],
    ["src/pages/contact.astro", _page5],
    ["src/pages/favicon.ico.ts", _page6],
    ["src/pages/friends.astro", _page7],
    ["src/pages/posts/detail/[id].astro", _page8],
    ["src/pages/posts/index.astro", _page9],
    ["src/pages/robots.txt.ts", _page10],
    ["src/pages/rss.xml.ts", _page11],
    ["src/pages/search.astro", _page12],
    ["src/pages/timeline.astro", _page13],
    ["src/pages/index.astro", _page14]
]);

const _manifest = Object.assign(manifest, {
    pageMap,
    serverIslandMap,
    renderers,
    actions: () => import('./entrypoint.mjs'),
    middleware: () => import('./_noop-middleware.mjs')
});
const _args = {
    "mode": "standalone",
    "client": "file:///F:/shiyi-blog-master/gblog-gblog-template/dist/client/",
    "server": "file:///F:/shiyi-blog-master/gblog-gblog-template/dist/server/",
    "host": "0.0.0.0",
    "port": 7000,
    "assets": "_astro",
    "experimentalStaticHeaders": false
};
const _exports = createExports(_manifest, _args);
const handler = _exports['handler'];
const startServer = _exports['startServer'];
const options = _exports['options'];
const _start = 'start';
if (Object.prototype.hasOwnProperty.call(serverEntrypointModule, _start)) {
	serverEntrypointModule[_start](_manifest, _args);
}

export { handler, options, pageMap, startServer };

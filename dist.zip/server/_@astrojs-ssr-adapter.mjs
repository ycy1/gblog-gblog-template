export { c as createExports, a as start } from './chunks/_@astrojs-ssr-adapter_o8nLWo1L.mjs';
